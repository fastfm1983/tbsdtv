#!/bin/bash
sudo gcc -o /usr/local/bin/dvbls dvbls.c
